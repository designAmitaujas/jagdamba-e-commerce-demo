import React from 'react'
import Header from './Header';


const SingleProduct = () => {
  return (
    <div>
      <Header/>
      <div className="container">
        hello
      </div>
      <h1 className="h3 container mb-4">Whirlpool 192 L Direct Cool Single Door 4 Star Refrigerator</h1>

    </div>
    
  )
}

export default SingleProduct