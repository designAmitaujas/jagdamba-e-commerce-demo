import React from 'react'
import { Container, Row, Col, Form, Card, Badge, Button } from "react-bootstrap"
import { Star, Heart, ShoppingCart, Check, Filter } from "lucide-react"
import Navbars from './Header'

const TvList = () => {
  return (
 <div>
  TVLIST
 </div>
  )
}

export default TvList